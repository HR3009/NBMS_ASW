/*
 * File: NBMS_DischargeOCV_private.h
 *
 * Code generated for Simulink model 'NBMS_DischargeOCV'.
 *
 * Model version                  : 7.6
 * Simulink Coder version         : 26.2 (R2026b) 22-May-2026
 * C/C++ source code generated on : Fri Nov 20 12:34:51 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef NBMS_DischargeOCV_private_h_
#define NBMS_DischargeOCV_private_h_
#include "rtwtypes.h"
#include "NBMS_DischargeOCV_types.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFFFFFU) ) || ( INT_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFU) ) || ( LONG_MAX != (0x7FFFFFFF) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         (*((rtm)->errorStatus))
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    (*((rtm)->errorStatus) = (val))
#endif

#ifndef rtmGetErrorStatusPointer
#define rtmGetErrorStatusPointer(rtm)  (rtm)->errorStatus
#endif

#ifndef rtmSetErrorStatusPointer
#define rtmSetErrorStatusPointer(rtm, val) ((rtm)->errorStatus = (val))
#endif

extern const uint32_T rtCP_pooled_OJvaNeQ52mdS[2];

#define rtCP_OCVvsSOCatallTemp2_maxInde rtCP_pooled_OJvaNeQ52mdS /* Computed Parameter: rtCP_OCVvsSOCatallTemp2_maxInde
                                                                  * Referenced by: '<S1>/OCV vs SOC at all Temp2'
                                                                  */
#define rtCP_OCVvsSOCatallTemp1_maxInde rtCP_pooled_OJvaNeQ52mdS /* Computed Parameter: rtCP_OCVvsSOCatallTemp1_maxInde
                                                                  * Referenced by: '<S1>/OCV vs SOC at all Temp1'
                                                                  */
#define rtCP_OCVvsSOCatallTemp_maxIndex rtCP_pooled_OJvaNeQ52mdS /* Computed Parameter: rtCP_OCVvsSOCatallTemp_maxIndex
                                                                  * Referenced by: '<S1>/OCV vs SOC at all Temp'
                                                                  */
#endif                                 /* NBMS_DischargeOCV_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
